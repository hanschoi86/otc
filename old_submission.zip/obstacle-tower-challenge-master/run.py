
from obstacle_tower_env import ObstacleTowerEnv
import sys
import argparse
import gin.tf

sys.path.append('dopamine')
from dopamine.discrete_domains import run_experiment

def run_evaluation(env):
    while not env.done_grading():
        runner._run_one_episode()
        runner._initialize_episode()

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('environment_filename', default='./ObstacleTower/obstacletower', nargs='?')
    parser.add_argument('--docker_training', action='store_true')
    parser.set_defaults(docker_training=False)
    args = parser.parse_args()

    env = ObstacleTowerEnv(args.environment_filename, docker_training=args.docker_training, retro=True, timeout_wait=600)
    run_experiment.load_gin_configs(['hans_agent/rainbow_otc_light_load.gin'], [])
    runner = run_experiment.create_runner('hans_agent', env)
    
    if env.is_grading():
        episode_reward = run_evaluation(env)
    else:
        while True:
            episode_reward = run_episode(env)
            print("Episode reward: " + str(episode_reward))
            env.reset()

    env.close()
